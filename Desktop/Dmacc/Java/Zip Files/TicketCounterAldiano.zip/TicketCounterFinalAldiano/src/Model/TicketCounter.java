package Model;
public class TicketCounter {
	int TICKET_TOTAL = 45;
	int TICKET_INPUT = 0;
	private String TICKET_AMOUNT = "45";
	private String ticketInput = "0";
	

	public int getTICKET_INPUT() {
		return TICKET_INPUT;
	}

	public void setTICKET_INPUT(int tICKET_INPUT) {
		TICKET_INPUT = tICKET_INPUT;
	}

	public int getTICKET_TOTAL() {
		return TICKET_TOTAL;
	}

	public void setTICKET_TOTAL(int tICKET_TOTAL) {
		TICKET_TOTAL = tICKET_TOTAL;
	}

	public String getTICKET_AMOUNT() {
		return TICKET_AMOUNT;
	}

	public void setTICKET_AMOUNT(String tICKET_AMOUNT) {
		TICKET_AMOUNT = tICKET_AMOUNT;
	}

	public String getTicketInput() {
		return ticketInput;
	}

	public void setTicketInput(String TicketInput) {
		TicketInput = ticketInput;
	}

	
	
	
	
		
	

}
