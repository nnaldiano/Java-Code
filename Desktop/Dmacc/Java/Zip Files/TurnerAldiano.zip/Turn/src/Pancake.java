
public class Pancake implements Turner {

	@Override
	public String turn() {
		String PANCAKE = "Flipping!";
		return PANCAKE;
	}

	

}
