
public class Page implements Turner{

	@Override
	public String turn() {
		String PAGE = "Going to next page";
		return PAGE;
	}

	

}
