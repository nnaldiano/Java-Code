
public class Leaf implements Turner {

	@Override
	public String turn() {
		String LEAF = "Changing colors";
		return LEAF;
	}

	
	

}
