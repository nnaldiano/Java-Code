
public class LeagueTesterAldiano {

	public static void main(String[] args) {
		Team DuneRatz = new Team("Dune Ratz", 7, "Captain Kadeem");
		Team Scorchers = new Team("Scorchers", 7, "Captain Taro");
		Team WaveRippers = new Team("Wave Rippers", 7, "Captain Vert");
		Team StreetBeasts = new Team("StreetBeasts", 7, "Captain Banjee");

		System.out.println(DuneRatz.TeamString());
		System.out.println(Scorchers.TeamString());
		System.out.println(WaveRippers.TeamString());
		System.out.println(StreetBeasts.TeamString());

		

	}

}
